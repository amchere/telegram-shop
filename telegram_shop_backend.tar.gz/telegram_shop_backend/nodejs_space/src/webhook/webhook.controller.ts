import { Controller, Post, Body, Headers, Logger } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiHeader } from '@nestjs/swagger';
import { WebhookService } from './webhook.service';

@ApiTags('Webhook')
@Controller('webhook')
export class WebhookController {
  private readonly logger = new Logger(WebhookController.name);

  constructor(private readonly webhookService: WebhookService) {}

  @Post('telegram')
  @ApiOperation({ summary: 'Telegram Bot webhook endpoint' })
  @ApiHeader({ name: 'X-Telegram-Bot-Api-Secret-Token', required: false })
  @ApiResponse({ status: 200, description: 'Update processed' })
  @ApiResponse({ status: 401, description: 'Invalid webhook secret' })
  async handleTelegramWebhook(
    @Body() update: any,
    @Headers('x-telegram-bot-api-secret-token') secret: string,
  ): Promise<{ success: boolean }> {
    this.logger.log('Telegram webhook received');
    return this.webhookService.handleTelegramUpdate(update, secret);
  }
}

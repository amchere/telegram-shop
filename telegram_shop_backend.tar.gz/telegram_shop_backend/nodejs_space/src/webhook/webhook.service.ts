import { Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class WebhookService {
  private readonly logger = new Logger(WebhookService.name);
  private readonly webhookSecret: string;

  constructor(private configService: ConfigService) {
    this.webhookSecret = this.configService.get<string>('TELEGRAM_WEBHOOK_SECRET', '');
  }

  validateWebhookSecret(secret: string): boolean {
    if (!this.webhookSecret) {
      this.logger.warn('Telegram webhook secret not configured');
      return true; // Allow in dev if not configured
    }
    return secret === this.webhookSecret;
  }

  async handleTelegramUpdate(update: any, secret: string): Promise<{ success: boolean }> {
    if (!this.validateWebhookSecret(secret)) {
      throw new UnauthorizedException('Invalid webhook secret');
    }

    this.logger.log(`Received Telegram update: ${JSON.stringify(update)}`);

    // Process the update (in a real implementation, this would be delegated to a bot handler)
    // For MVP, we just log it and return success
    // The actual bot logic should be implemented separately

    return { success: true };
  }

  async sendNotificationToAdmin(message: string): Promise<void> {
    const botToken = this.configService.get<string>('TELEGRAM_BOT_TOKEN');
    const chatId = this.configService.get<string>('TELEGRAM_ADMIN_CHAT_ID');

    if (!botToken || !chatId) {
      this.logger.warn('Telegram bot not configured for admin notifications');
      return;
    }

    try {
      const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: 'HTML',
        }),
      });

      if (!response.ok) {
        throw new Error(`Telegram API error: ${response.statusText}`);
      }

      this.logger.log('Admin notification sent successfully');
    } catch (error) {
      this.logger.error('Failed to send admin notification', error);
    }
  }
}

import { Injectable, UnauthorizedException, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import { LoginDto } from './dto/login.dto';
import { TokenResponseDto } from './dto/token-response.dto';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private prisma: PrismaService,
    private jwtService: JwtService,
    private configService: ConfigService,
  ) {}

  async login(loginDto: LoginDto): Promise<TokenResponseDto> {
    const { username, password } = loginDto;

    const admin = await this.prisma.admin_users.findUnique({
      where: { username },
    });

    if (!admin || !admin.is_active) {
      this.logger.warn(`Failed login attempt for username: ${username}`);
      throw new UnauthorizedException('Incorrect username or password');
    }

    const isPasswordValid = await bcrypt.compare(password, admin.password_hash);
    if (!isPasswordValid) {
      this.logger.warn(`Invalid password for username: ${username}`);
      throw new UnauthorizedException('Incorrect username or password');
    }

    const payload = { sub: admin.id, username: admin.username, role: admin.role };
    const access_token = this.jwtService.sign(payload);

    this.logger.log(`User ${username} logged in successfully`);

    return {
      access_token,
      token_type: 'bearer',
    };
  }

  async validateUser(username: string, password: string): Promise<any> {
    const admin = await this.prisma.admin_users.findUnique({
      where: { username },
    });

    if (admin && await bcrypt.compare(password, admin.password_hash)) {
      const { password_hash, ...result } = admin;
      return result;
    }
    return null;
  }

  // Helper method to hash passwords (for seeding)
  async hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, 10);
  }
}

import { Injectable, NotFoundException, Logger, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { ProductListQueryDto, ProductListResponseDto } from './dto/product-list.dto';
import { ProductDetailDto } from './dto/product-detail.dto';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { CategoryDto } from './dto/category.dto';

@Injectable()
export class ProductsService {
  private readonly logger = new Logger(ProductsService.name);

  constructor(private prisma: PrismaService) {}

  async getProducts(query: ProductListQueryDto, includeInactive = false): Promise<ProductListResponseDto> {
    const { category_id, page = 1, size = 10 } = query;
    const skip = (page - 1) * size;

    const where: any = {};
    if (category_id) {
      where.category_id = category_id;
    }
    if (!includeInactive) {
      where.is_active = true;
    }

    const [products, total] = await Promise.all([
      this.prisma.products.findMany({
        where,
        skip,
        take: size,
        include: {
          variants: {
            select: { price: true },
          },
        },
        orderBy: { created_at: 'desc' },
      }),
      this.prisma.products.count({ where }),
    ]);

    const items = products.map((product) => {
      const prices = product.variants.map((v) => Number(v.price));
      return {
        id: product.id,
        name: product.name,
        description: product.description,
        category_id: product.category_id,
        is_active: product.is_active,
        price_range: {
          min: Math.min(...prices),
          max: Math.max(...prices),
        },
      };
    });

    return { items, total, page, size };
  }

  async getProductById(id: number): Promise<ProductDetailDto> {
    const product = await this.prisma.products.findUnique({
      where: { id },
      include: {
        variants: {
          include: {
            variant_values: {
              include: {
                option_value: {
                  include: {
                    option_type: true,
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    // Extract unique option types and values
    const optionsMap = new Map<string, Set<string>>();
    product.variants.forEach((variant) => {
      variant.variant_values.forEach((vv) => {
        const typeName = vv.option_value.option_type.name;
        const value = vv.option_value.value;
        if (!optionsMap.has(typeName)) {
          optionsMap.set(typeName, new Set());
        }
        optionsMap.get(typeName)!.add(value);
      });
    });

    const options = Array.from(optionsMap.entries()).map(([name, values]) => ({
      name,
      values: Array.from(values),
    }));

    const variants = product.variants.map((variant) => ({
      id: variant.id,
      sku: variant.sku,
      price: Number(variant.price),
      stock_quantity: variant.stock_quantity,
      weight: variant.weight ? Number(variant.weight) : undefined,
      dimensions: variant.dimensions || undefined,
      images: variant.images || [],
      attributes: variant.variant_values.map((vv) => ({
        type: vv.option_value.option_type.name,
        value: vv.option_value.value,
      })),
    }));

    return {
      id: product.id,
      name: product.name,
      description: product.description,
      category_id: product.category_id,
      is_active: product.is_active,
      options,
      variants,
    };
  }

  async createProduct(dto: CreateProductDto): Promise<ProductDetailDto> {
    this.logger.log(`Creating product: ${dto.name}`);

    // Verify category exists
    const category = await this.prisma.categories.findUnique({
      where: { id: dto.category_id },
    });
    if (!category) {
      throw new BadRequestException(`Category with ID ${dto.category_id} not found`);
    }

    // Create product with variants
    const product = await this.prisma.products.create({
      data: {
        name: dto.name,
        description: dto.description,
        category_id: dto.category_id,
        is_active: dto.is_active ?? true,
        variants: {
          create: await Promise.all(
            dto.variants.map(async (variantDto) => {
              // Create or find option types and values
              const variantValuesData = await this.processVariantAttributes(
                variantDto.attributes || [],
              );

              return {
                sku: variantDto.sku,
                price: variantDto.price,
                stock_quantity: variantDto.stock_quantity,
                weight: variantDto.weight,
                dimensions: variantDto.dimensions,
                images: variantDto.images || [],
                variant_values: {
                  create: variantValuesData,
                },
              };
            }),
          ),
        },
      },
    });

    this.logger.log(`Product created with ID: ${product.id}`);
    return this.getProductById(product.id);
  }

  async updateProduct(id: number, dto: UpdateProductDto): Promise<ProductDetailDto> {
    this.logger.log(`Updating product ID: ${id}`);

    const existing = await this.prisma.products.findUnique({ where: { id } });
    if (!existing) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    // Delete existing variants if new ones provided
    if (dto.variants) {
      await this.prisma.product_variants.deleteMany({
        where: { product_id: id },
      });
    }

    await this.prisma.products.update({
      where: { id },
      data: {
        ...(dto.name && { name: dto.name }),
        ...(dto.description && { description: dto.description }),
        ...(dto.category_id && { category_id: dto.category_id }),
        ...(dto.is_active !== undefined && { is_active: dto.is_active }),
        ...(dto.variants && {
          variants: {
            create: await Promise.all(
              dto.variants.map(async (variantDto) => {
                const variantValuesData = await this.processVariantAttributes(
                  variantDto.attributes || [],
                );
                return {
                  sku: variantDto.sku,
                  price: variantDto.price,
                  stock_quantity: variantDto.stock_quantity,
                  weight: variantDto.weight,
                  dimensions: variantDto.dimensions,
                  images: variantDto.images || [],
                  variant_values: {
                    create: variantValuesData,
                  },
                };
              }),
            ),
          },
        }),
      },
    });

    this.logger.log(`Product updated: ${id}`);
    return this.getProductById(id);
  }

  async deleteProduct(id: number): Promise<void> {
    this.logger.log(`Deleting product ID: ${id}`);

    const existing = await this.prisma.products.findUnique({ where: { id } });
    if (!existing) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    await this.prisma.products.delete({ where: { id } });
    this.logger.log(`Product deleted: ${id}`);
  }

  async getCategories(): Promise<CategoryDto[]> {
    const categories = await this.prisma.categories.findMany({
      orderBy: { name: 'asc' },
    });

    return categories.map((cat) => ({
      id: cat.id,
      name: cat.name,
      parent_id: cat.parent_id,
    }));
  }

  private async processVariantAttributes(attributes: any[]): Promise<any[]> {
    const variantValuesData: any[] = [];

    for (const attr of attributes) {
      // Find or create option type
      let optionType = await this.prisma.option_types.findUnique({
        where: { name: attr.type },
      });

      if (!optionType) {
        optionType = await this.prisma.option_types.create({
          data: { name: attr.type },
        });
      }

      // Find or create option value
      let optionValue = await this.prisma.option_values.findFirst({
        where: {
          option_type_id: optionType.id,
          value: attr.value,
        },
      });

      if (!optionValue) {
        optionValue = await this.prisma.option_values.create({
          data: {
            option_type_id: optionType.id,
            value: attr.value,
          },
        });
      }

      variantValuesData.push({
        option_value_id: optionValue.id,
      });
    }

    return variantValuesData;
  }
}

import { ApiProperty } from '@nestjs/swagger';

export class VariantAttributeDto {
  @ApiProperty({ example: 'Color' })
  type: string;

  @ApiProperty({ example: 'Red' })
  value: string;
}

export class ProductVariantDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  sku: string;

  @ApiProperty()
  price: number;

  @ApiProperty()
  stock_quantity: number;

  @ApiProperty({ type: [VariantAttributeDto] })
  attributes: VariantAttributeDto[];

  @ApiProperty({ required: false })
  weight?: number;

  @ApiProperty({ required: false })
  dimensions?: string;

  @ApiProperty({ type: [String], required: false })
  images?: string[];
}

export class OptionTypeDto {
  @ApiProperty()
  name: string;

  @ApiProperty({ type: [String] })
  values: string[];
}

export class ProductDetailDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  name: string;

  @ApiProperty()
  description: string;

  @ApiProperty()
  category_id: number;

  @ApiProperty()
  is_active: boolean;

  @ApiProperty({ type: [OptionTypeDto] })
  options: OptionTypeDto[];

  @ApiProperty({ type: [ProductVariantDto] })
  variants: ProductVariantDto[];
}

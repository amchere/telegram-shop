import { Controller, Get, Post, Put, Delete, Param, Query, Body, UseGuards, Logger, ParseIntPipe, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { ProductsService } from './products.service';
import { ProductListQueryDto, ProductListResponseDto } from './dto/product-list.dto';
import { ProductDetailDto } from './dto/product-detail.dto';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { CategoryDto } from './dto/category.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';

@ApiTags('Products')
@Controller('products')
export class ProductsController {
  private readonly logger = new Logger(ProductsController.name);

  constructor(private readonly productsService: ProductsService) {}

  @Get()
  @ApiOperation({ summary: 'Get list of active products' })
  @ApiResponse({ status: 200, type: ProductListResponseDto })
  async getProducts(@Query() query: ProductListQueryDto): Promise<ProductListResponseDto> {
    this.logger.log('Fetching products list');
    return this.productsService.getProducts(query, false);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get product details by ID' })
  @ApiResponse({ status: 200, type: ProductDetailDto })
  @ApiResponse({ status: 404, description: 'Product not found' })
  async getProductById(@Param('id', ParseIntPipe) id: number): Promise<ProductDetailDto> {
    this.logger.log(`Fetching product ID: ${id}`);
    return this.productsService.getProductById(id);
  }
}

@ApiTags('Products')
@Controller('categories')
export class CategoriesController {
  private readonly logger = new Logger(CategoriesController.name);

  constructor(private readonly productsService: ProductsService) {}

  @Get()
  @ApiOperation({ summary: 'Get all categories' })
  @ApiResponse({ status: 200, type: [CategoryDto] })
  async getCategories(): Promise<CategoryDto[]> {
    this.logger.log('Fetching categories');
    return this.productsService.getCategories();
  }
}

@ApiTags('Admin - Products')
@Controller('admin/products')
@UseGuards(JwtAuthGuard, RolesGuard)
@ApiBearerAuth()
export class AdminProductsController {
  private readonly logger = new Logger(AdminProductsController.name);

  constructor(private readonly productsService: ProductsService) {}

  @Get()
  @Roles('admin', 'manager')
  @ApiOperation({ summary: 'Get all products (including inactive)' })
  @ApiResponse({ status: 200, type: ProductListResponseDto })
  async getAdminProducts(@Query() query: ProductListQueryDto): Promise<ProductListResponseDto> {
    this.logger.log('Admin fetching all products');
    return this.productsService.getProducts(query, true);
  }

  @Post()
  @Roles('admin', 'manager')
  @ApiOperation({ summary: 'Create new product' })
  @ApiResponse({ status: 201, type: ProductDetailDto })
  @ApiResponse({ status: 422, description: 'Validation error' })
  async createProduct(@Body() dto: CreateProductDto): Promise<ProductDetailDto> {
    this.logger.log('Admin creating product');
    return this.productsService.createProduct(dto);
  }

  @Put(':id')
  @Roles('admin', 'manager')
  @ApiOperation({ summary: 'Update product' })
  @ApiResponse({ status: 200, type: ProductDetailDto })
  @ApiResponse({ status: 404, description: 'Product not found' })
  async updateProduct(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateProductDto,
  ): Promise<ProductDetailDto> {
    this.logger.log(`Admin updating product ID: ${id}`);
    return this.productsService.updateProduct(id, dto);
  }

  @Delete(':id')
  @Roles('admin')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Delete product' })
  @ApiResponse({ status: 204, description: 'Product deleted' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  async deleteProduct(@Param('id', ParseIntPipe) id: number): Promise<void> {
    this.logger.log(`Admin deleting product ID: ${id}`);
    await this.productsService.deleteProduct(id);
  }
}

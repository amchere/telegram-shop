import { Controller, Post, Get, Patch, Param, Query, Body, UseGuards, Logger, ParseIntPipe } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { OrdersService } from './orders.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { OrderResponseDto } from './dto/order-response.dto';
import { AdminOrderQueryDto, AdminOrderListResponseDto, AdminOrderDetailDto, UpdateOrderStatusDto } from './dto/admin-order.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';

@ApiTags('Orders')
@Controller('orders')
export class OrdersController {
  private readonly logger = new Logger(OrdersController.name);

  constructor(private readonly ordersService: OrdersService) {}

  @Post()
  @ApiOperation({ summary: 'Create new order' })
  @ApiResponse({ status: 201, type: OrderResponseDto })
  @ApiResponse({ status: 400, description: 'Validation error or out of stock' })
  async createOrder(@Body() dto: CreateOrderDto): Promise<OrderResponseDto> {
    this.logger.log('Creating new order');
    return this.ordersService.createOrder(dto);
  }
}

@ApiTags('Admin - Orders')
@Controller('admin/orders')
@UseGuards(JwtAuthGuard, RolesGuard)
@ApiBearerAuth()
export class AdminOrdersController {
  private readonly logger = new Logger(AdminOrdersController.name);

  constructor(private readonly ordersService: OrdersService) {}

  @Get()
  @Roles('admin', 'manager')
  @ApiOperation({ summary: 'Get all orders' })
  @ApiResponse({ status: 200, type: AdminOrderListResponseDto })
  async getAdminOrders(@Query() query: AdminOrderQueryDto): Promise<AdminOrderListResponseDto> {
    this.logger.log('Admin fetching orders');
    return this.ordersService.getAdminOrders(query);
  }

  @Get(':id')
  @Roles('admin', 'manager')
  @ApiOperation({ summary: 'Get order details' })
  @ApiResponse({ status: 200, type: AdminOrderDetailDto })
  @ApiResponse({ status: 404, description: 'Order not found' })
  async getAdminOrderById(@Param('id', ParseIntPipe) id: number): Promise<AdminOrderDetailDto> {
    this.logger.log(`Admin fetching order ID: ${id}`);
    return this.ordersService.getAdminOrderById(id);
  }

  @Patch(':id')
  @Roles('admin', 'manager')
  @ApiOperation({ summary: 'Update order status' })
  @ApiResponse({ status: 200, type: AdminOrderDetailDto })
  @ApiResponse({ status: 404, description: 'Order not found' })
  async updateOrderStatus(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateOrderStatusDto,
  ): Promise<AdminOrderDetailDto> {
    this.logger.log(`Admin updating order ${id} status`);
    return this.ordersService.updateOrderStatus(id, dto);
  }
}

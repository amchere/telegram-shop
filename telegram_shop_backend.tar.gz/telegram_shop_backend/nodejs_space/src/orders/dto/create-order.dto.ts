import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, IsArray, ValidateNested, IsInt, Min, IsObject } from 'class-validator';
import { Type } from 'class-transformer';

export class OrderItemDto {
  @ApiProperty({ example: 101 })
  @IsInt()
  variant_id: number;

  @ApiProperty({ example: 2, minimum: 1 })
  @IsInt()
  @Min(1)
  quantity: number;
}

export class UserDetailsDto {
  @ApiProperty({ example: 'John Doe' })
  @IsString()
  @IsNotEmpty()
  full_name: string;

  @ApiProperty({ example: '+15551234567' })
  @IsString()
  @IsNotEmpty()
  phone_number: string;
}

export class CreateOrderDto {
  @ApiProperty({ example: 123456789, description: 'Telegram User ID' })
  @IsInt()
  user_id: number;

  @ApiProperty({ type: UserDetailsDto })
  @IsObject()
  @ValidateNested()
  @Type(() => UserDetailsDto)
  user_details: UserDetailsDto;

  @ApiProperty({ example: '123 Main St, Anytown, USA' })
  @IsString()
  @IsNotEmpty()
  shipping_address: string;

  @ApiProperty({ type: [OrderItemDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => OrderItemDto)
  items: OrderItemDto[];
}

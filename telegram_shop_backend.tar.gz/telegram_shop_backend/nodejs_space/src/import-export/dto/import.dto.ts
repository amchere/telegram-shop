import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsOptional, IsUrl } from 'class-validator';

export class GoogleSheetsImportDto {
  @ApiProperty({ example: 'https://docs.google.com/spreadsheets/d/1ABC.../edit' })
  @IsString()
  @IsUrl()
  spreadsheet_url: string;

  @ApiProperty({ required: false, default: 'Sheet1' })
  @IsOptional()
  @IsString()
  sheet_name?: string = 'Sheet1';
}

export class ImportResponseDto {
  @ApiProperty()
  task_id: string;

  @ApiProperty()
  message: string;
}

import { Injectable, BadRequestException, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import * as papa from 'papaparse';
import * as ExcelJS from 'exceljs';
import { google } from 'googleapis';
import { ExportQueryDto, GoogleSheetsExportDto } from './dto/export.dto';
import { GoogleSheetsImportDto, ImportResponseDto } from './dto/import.dto';
import { Readable } from 'stream';

@Injectable()
export class ImportExportService {
  private readonly logger = new Logger(ImportExportService.name);
  private sheets: any;

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {
    this.initializeGoogleSheets();
  }

  private initializeGoogleSheets() {
    try {
      const email = this.configService.get<string>('GOOGLE_SERVICE_ACCOUNT_EMAIL');
      const privateKey = this.configService.get<string>('GOOGLE_PRIVATE_KEY');

      if (email && privateKey) {
        const auth = new google.auth.GoogleAuth({
          credentials: {
            client_email: email,
            private_key: privateKey.replace(/\\n/g, '\n'),
          },
          scopes: ['https://www.googleapis.com/auth/spreadsheets'],
        });

        this.sheets = google.sheets({ version: 'v4', auth });
        this.logger.log('✅ Google Sheets API initialized');
      } else {
        this.logger.warn('⚠️  Google Sheets credentials not configured');
      }
    } catch (error) {
      this.logger.error('Failed to initialize Google Sheets API', error);
    }
  }

  async importFromCSV(file: Express.Multer.File): Promise<ImportResponseDto> {
    this.logger.log('Starting CSV import');

    try {
      const content = file.buffer.toString('utf-8');
      const parsed = papa.parse(content, {
        header: true,
        skipEmptyLines: true,
      });

      await this.processImportData(parsed.data);

      return {
        task_id: `import_${Date.now()}`,
        message: `Imported ${parsed.data.length} products successfully`,
      };
    } catch (error) {
      this.logger.error('CSV import failed', error);
      throw new BadRequestException('Failed to import CSV file');
    }
  }

  async importFromXLSX(file: Express.Multer.File): Promise<ImportResponseDto> {
    this.logger.log('Starting XLSX import');

    try {
      const workbook = new ExcelJS.Workbook();
      await workbook.xlsx.load(file.buffer as any);
      const worksheet = workbook.getWorksheet(1);

      if (!worksheet) {
        throw new BadRequestException('No worksheet found in XLSX file');
      }

      const data: any[] = [];
      const headers: string[] = [];

      worksheet.eachRow((row, rowNumber) => {
        if (rowNumber === 1) {
          row.eachCell((cell) => {
            headers.push(cell.value?.toString() || '');
          });
        } else {
          const rowData: any = {};
          row.eachCell((cell, colNumber) => {
            rowData[headers[colNumber - 1]] = cell.value;
          });
          data.push(rowData);
        }
      });

      await this.processImportData(data);

      return {
        task_id: `import_${Date.now()}`,
        message: `Imported ${data.length} products successfully`,
      };
    } catch (error) {
      this.logger.error('XLSX import failed', error);
      throw new BadRequestException('Failed to import XLSX file');
    }
  }

  async importFromGoogleSheets(dto: GoogleSheetsImportDto): Promise<ImportResponseDto> {
    this.logger.log('Starting Google Sheets import');

    if (!this.sheets) {
      throw new BadRequestException('Google Sheets API not configured');
    }

    try {
      const spreadsheetId = this.extractSpreadsheetId(dto.spreadsheet_url);
      const range = `${dto.sheet_name || 'Sheet1'}!A:Z`;

      const response = await this.sheets.spreadsheets.values.get({
        spreadsheetId,
        range,
      });

      const rows = response.data.values;
      if (!rows || rows.length === 0) {
        throw new BadRequestException('No data found in spreadsheet');
      }

      const headers = rows[0];
      const data = rows.slice(1).map((row: any[]) => {
        const obj: any = {};
        headers.forEach((header: string, index: number) => {
          obj[header] = row[index];
        });
        return obj;
      });

      await this.processImportData(data);

      return {
        task_id: `import_${Date.now()}`,
        message: `Imported ${data.length} products from Google Sheets`,
      };
    } catch (error) {
      this.logger.error('Google Sheets import failed', error);
      throw new BadRequestException('Failed to import from Google Sheets');
    }
  }

  async exportToCSV(query: ExportQueryDto): Promise<Buffer> {
    this.logger.log('Exporting orders to CSV');

    const orders = await this.getOrdersForExport(query);
    const csvData = this.ordersToCSV(orders);
    return Buffer.from(csvData, 'utf-8');
  }

  async exportToXLSX(query: ExportQueryDto): Promise<Buffer> {
    this.logger.log('Exporting orders to XLSX');

    const orders = await this.getOrdersForExport(query);
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Orders');

    worksheet.columns = [
      { header: 'Order ID', key: 'id', width: 10 },
      { header: 'Customer', key: 'customer', width: 30 },
      { header: 'Status', key: 'status', width: 15 },
      { header: 'Total Amount', key: 'total', width: 15 },
      { header: 'Created At', key: 'created_at', width: 20 },
    ];

    orders.forEach((order: any) => {
      worksheet.addRow({
        id: order.id,
        customer: order.customer_contact,
        status: order.status,
        total: Number(order.total_amount),
        created_at: order.created_at.toISOString(),
      });
    });

    const buffer = await workbook.xlsx.writeBuffer();
    return Buffer.from(buffer);
  }

  async exportToGoogleSheets(dto: GoogleSheetsExportDto): Promise<{ spreadsheet_url: string; message: string }> {
    this.logger.log('Exporting orders to Google Sheets');

    if (!this.sheets) {
      throw new BadRequestException('Google Sheets API not configured');
    }

    const orders = await this.getOrdersForExport(dto);

    const values = [
      ['Order ID', 'Customer', 'Status', 'Total Amount', 'Created At'],
      ...orders.map((order: any) => [
        order.id,
        order.customer_contact,
        order.status,
        Number(order.total_amount),
        order.created_at.toISOString(),
      ]),
    ];

    try {
      let spreadsheetId: string;

      if (dto.spreadsheet_url) {
        spreadsheetId = this.extractSpreadsheetId(dto.spreadsheet_url);
      } else {
        const spreadsheet = await this.sheets.spreadsheets.create({
          resource: {
            properties: {
              title: `Orders Export ${new Date().toISOString()}`,
            },
          },
        });
        spreadsheetId = spreadsheet.data.spreadsheetId;
      }

      await this.sheets.spreadsheets.values.update({
        spreadsheetId,
        range: 'Sheet1!A1',
        valueInputOption: 'RAW',
        resource: { values },
      });

      const url = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;
      return {
        spreadsheet_url: url,
        message: 'Orders exported successfully',
      };
    } catch (error) {
      this.logger.error('Google Sheets export failed', error);
      throw new BadRequestException('Failed to export to Google Sheets');
    }
  }

  private async processImportData(data: any[]): Promise<void> {
    // Process each row and create/update products
    for (const row of data) {
      try {
        // Expected columns: name, description, category_id, sku, price, stock_quantity
        const { name, description, category_id, sku, price, stock_quantity } = row;

        if (!name || !sku) {
          this.logger.warn(`Skipping row with missing name or SKU`);
          continue;
        }

        // Find or create product
        let product = await this.prisma.products.findFirst({
          where: { name },
        });

        if (!product) {
          product = await this.prisma.products.create({
            data: {
              name,
              description: description || '',
              category_id: parseInt(category_id) || 1,
              is_active: true,
            },
          });
        }

        // Create or update variant
        await this.prisma.product_variants.upsert({
          where: { sku },
          update: {
            price: parseFloat(price),
            stock_quantity: parseInt(stock_quantity),
          },
          create: {
            product_id: product.id,
            sku,
            price: parseFloat(price),
            stock_quantity: parseInt(stock_quantity),
            images: [],
          },
        });
      } catch (error) {
        this.logger.error(`Failed to process row: ${JSON.stringify(row)}`, error);
      }
    }
  }

  private async getOrdersForExport(query: ExportQueryDto): Promise<any[]> {
    const where: any = {};

    if (query.start_date || query.end_date) {
      where.created_at = {};
      if (query.start_date) {
        where.created_at.gte = new Date(query.start_date);
      }
      if (query.end_date) {
        where.created_at.lte = new Date(query.end_date);
      }
    }

    return this.prisma.orders.findMany({
      where,
      orderBy: { created_at: 'desc' },
    });
  }

  private ordersToCSV(orders: any[]): string {
    const headers = ['Order ID', 'Customer', 'Status', 'Total Amount', 'Created At'];
    const rows = orders.map((order) => [
      order.id,
      order.customer_contact,
      order.status,
      Number(order.total_amount),
      order.created_at.toISOString(),
    ]);

    return papa.unparse([headers, ...rows]);
  }

  private extractSpreadsheetId(url: string): string {
    const match = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (!match) {
      throw new BadRequestException('Invalid Google Sheets URL');
    }
    return match[1];
  }
}

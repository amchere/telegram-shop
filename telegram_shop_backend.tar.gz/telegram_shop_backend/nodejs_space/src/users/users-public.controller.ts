import { Controller, Get, Post, Param, Body, Logger, ParseIntPipe, NotFoundException } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { UsersService } from './users.service';
import { UserDto, UpsertTelegramUserDto } from './dto/user.dto';

@ApiTags('Users (Public)')
@Controller('users')
export class UsersPublicController {
  private readonly logger = new Logger(UsersPublicController.name);

  constructor(private readonly usersService: UsersService) {}

  @Get('telegram/:telegramId')
  @ApiOperation({ summary: 'Get user by Telegram ID (for bot)' })
  @ApiResponse({ status: 200, type: UserDto })
  @ApiResponse({ status: 404, description: 'User not found' })
  async getUserByTelegramId(
    @Param('telegramId', ParseIntPipe) telegramId: number,
  ): Promise<UserDto> {
    this.logger.log(`Fetching user with telegram_id: ${telegramId}`);
    const user = await this.usersService.getUserByTelegramId(telegramId);
    
    if (!user) {
      throw new NotFoundException(`User with telegram_id ${telegramId} not found`);
    }
    
    return user;
  }

  @Post('upsert')
  @ApiOperation({ summary: 'Create or update Telegram user (for bot)' })
  @ApiResponse({ status: 200, type: UserDto })
  async upsertTelegramUser(
    @Body() data: UpsertTelegramUserDto,
  ): Promise<UserDto> {
    this.logger.log(`Upserting user with telegram_id: ${data.telegram_id}`);
    return this.usersService.upsertTelegramUser(data);
  }
}

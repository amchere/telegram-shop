import { Controller, Get, Param, Query, UseGuards, Logger, ParseIntPipe } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { UsersService } from './users.service';
import { UserListResponseDto, UserDetailDto } from './dto/user.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';

@ApiTags('Admin - Users')
@Controller('admin/users')
@UseGuards(JwtAuthGuard, RolesGuard)
@ApiBearerAuth()
export class UsersController {
  private readonly logger = new Logger(UsersController.name);

  constructor(private readonly usersService: UsersService) {}

  @Get()
  @Roles('admin', 'manager')
  @ApiOperation({ summary: 'Get list of users' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'size', required: false, type: Number })
  @ApiResponse({ status: 200, type: UserListResponseDto })
  async getUsers(
    @Query('page', ParseIntPipe) page = 1,
    @Query('size', ParseIntPipe) size = 20,
  ): Promise<UserListResponseDto> {
    this.logger.log('Admin fetching users');
    return this.usersService.getUsers(page, size);
  }

  @Get(':id')
  @Roles('admin', 'manager')
  @ApiOperation({ summary: 'Get user details' })
  @ApiResponse({ status: 200, type: UserDetailDto })
  @ApiResponse({ status: 404, description: 'User not found' })
  async getUserById(@Param('id') id: string): Promise<UserDetailDto> {
    this.logger.log(`Admin fetching user ID: ${id}`);
    return this.usersService.getUserById(id);
  }
}

import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UserDto, UserDetailDto, UserListResponseDto } from './dto/user.dto';

@Injectable()
export class UsersService {
  private readonly logger = new Logger(UsersService.name);

  constructor(private prisma: PrismaService) {}

  async getUsers(page = 1, size = 20): Promise<UserListResponseDto> {
    const skip = (page - 1) * size;

    const [users, total] = await Promise.all([
      this.prisma.users.findMany({
        skip,
        take: size,
        orderBy: { created_at: 'desc' },
      }),
      this.prisma.users.count(),
    ]);

    const items = users.map((user) => ({
      id: user.id.toString(),
      full_name: user.full_name,
      username: user.username,
      phone_number: user.phone_number,
      created_at: user.created_at,
    }));

    return { items, total, page, size };
  }

  async getUserById(id: string): Promise<UserDetailDto> {
    const user = await this.prisma.users.findUnique({
      where: { id: BigInt(id) },
      include: {
        orders: true,
      },
    });

    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }

    const totalSpent = user.orders.reduce(
      (sum, order) => sum + Number(order.total_amount),
      0,
    );

    return {
      id: user.id.toString(),
      full_name: user.full_name,
      username: user.username,
      phone_number: user.phone_number,
      created_at: user.created_at,
      orders_count: user.orders.length,
      total_spent: totalSpent,
    };
  }

  async getUserByTelegramId(telegramId: number): Promise<UserDto | null> {
    const user = await this.prisma.users.findUnique({
      where: { telegram_id: BigInt(telegramId) },
    });

    if (!user) {
      return null;
    }

    return {
      id: user.id.toString(),
      telegram_id: user.telegram_id?.toString(),
      full_name: user.full_name,
      username: user.username,
      phone_number: user.phone_number,
      created_at: user.created_at,
    };
  }

  async upsertTelegramUser(data: {
    telegram_id: number;
    username?: string;
    full_name?: string;
    phone_number?: string;
  }): Promise<UserDto> {
    this.logger.log(`Upserting user with telegram_id: ${data.telegram_id}`);

    const user = await this.prisma.users.upsert({
      where: { telegram_id: BigInt(data.telegram_id) },
      update: {
        username: data.username,
        full_name: data.full_name || undefined,
        phone_number: data.phone_number,
      },
      create: {
        telegram_id: BigInt(data.telegram_id),
        username: data.username,
        full_name: data.full_name || 'Unknown',
        phone_number: data.phone_number,
      },
    });

    return {
      id: user.id.toString(),
      telegram_id: user.telegram_id?.toString(),
      full_name: user.full_name,
      username: user.username,
      phone_number: user.phone_number,
      created_at: user.created_at,
    };
  }
}

import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getHealthCheck(): { message: string; timestamp: string; version: string } {
    return {
      message: 'Telegram Store API is running',
      timestamp: new Date().toISOString(),
      version: '1.0.0',
    };
  }
}

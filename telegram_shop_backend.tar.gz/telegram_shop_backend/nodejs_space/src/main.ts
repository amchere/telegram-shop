import { NestFactory } from '@nestjs/core';
import { ValidationPipe, Logger } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config';
import { AppModule } from './app.module';
import { AllExceptionsFilter } from './common/filters/http-exception.filter';

async function bootstrap() {
  const logger = new Logger('Bootstrap');
  const app = await NestFactory.create(AppModule, {
    logger: ['log', 'error', 'warn', 'debug'],
  });

  const configService = app.get(ConfigService);

  // Global prefix
  app.setGlobalPrefix('api');

  // CORS
  const corsOrigins = configService.get<string>('CORS_ORIGIN', '*').split(',');
  app.enableCors({
    origin: corsOrigins,
    credentials: true,
  });

  // Global pipes
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
    }),
  );

  // Global filters
  app.useGlobalFilters(new AllExceptionsFilter());

  // Swagger configuration
  const swaggerConfig = new DocumentBuilder()
    .setTitle('Telegram Store API')
    .setDescription(`
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
        <h2 style="color: #2c3e50; margin-top: 0;">REST API for Telegram Shop MVP</h2>
        
        <h3 style="color: #34495e; margin-top: 24px;">Key Features</h3>
        <ul style="line-height: 1.8; color: #555;">
          <li>Product catalog management with variants (color, size, etc.)</li>
          <li>Order processing and status tracking</li>
          <li>User management and order history</li>
          <li>JWT-based admin authentication</li>
          <li>CSV/XLSX/Google Sheets import/export</li>
          <li>Analytics integration (GA4, Yandex Metrika)</li>
          <li>Telegram Bot webhook support</li>
        </ul>

        <h3 style="color: #34495e; margin-top: 24px;">Authentication</h3>
        <p style="color: #555; line-height: 1.6;">
          Protected endpoints require a JWT access token in the Authorization header:
          <code style="background: #f5f5f5; padding: 2px 6px; border-radius: 3px;">Bearer &lt;token&gt;</code>
        </p>
        <p style="color: #555; line-height: 1.6;">
          Obtain tokens via <strong>POST /api/auth/token</strong> with admin credentials.
        </p>

        <div style="background: #e8f4f8; border-left: 4px solid #3498db; padding: 12px 16px; margin: 24px 0;">
          <p style="margin: 0; color: #2c3e50;">
            <strong>🔑 Default Admin Credentials (Development):</strong><br>
            Username: <code>admin</code><br>
            Password: <code>admin123</code>
          </p>
        </div>
      </div>
    `)
    .setVersion('1.0.0')
    .addBearerAuth(
      {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        description: 'Enter JWT access token',
      },
      'bearer',
    )
    .addTag('Authentication', 'Admin authentication and token management')
    .addTag('Products', 'Public product catalog endpoints')
    .addTag('Orders', 'Order creation for customers')
    .addTag('Admin - Products', 'Product management (requires authentication)')
    .addTag('Admin - Orders', 'Order management (requires authentication)')
    .addTag('Admin - Users', 'User management (requires authentication)')
    .addTag('Admin - Import/Export', 'Data import/export (requires authentication)')
    .addTag('Webhook', 'Telegram Bot webhook integration')
    .build();

  const document = SwaggerModule.createDocument(app, swaggerConfig);
  
  // Custom CSS for professional look
  const customCss = `
    .swagger-ui .topbar { display: none; }
    .swagger-ui .info { margin: 30px 0; }
    .swagger-ui .info .title { font-size: 32px; color: #2c3e50; font-weight: 600; }
    .swagger-ui .scheme-container { background: #fafafa; padding: 20px; border-radius: 8px; box-shadow: none; }
    .swagger-ui .btn.authorize { background-color: #3498db; border-color: #3498db; }
    .swagger-ui .btn.authorize:hover { background-color: #2980b9; }
    body { background-color: #f8f9fa; }
    .swagger-ui .info .description p { line-height: 1.7; }
    .swagger-ui .opblock-tag { font-size: 18px; font-weight: 600; color: #34495e; }
    .swagger-ui .opblock { border-radius: 6px; margin-bottom: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.08); }
    .swagger-ui .opblock.opblock-post { border-color: #49cc90; background: rgba(73, 204, 144, 0.05); }
    .swagger-ui .opblock.opblock-get { border-color: #61affe; background: rgba(97, 175, 254, 0.05); }
    .swagger-ui .opblock.opblock-put { border-color: #fca130; background: rgba(252, 161, 48, 0.05); }
    .swagger-ui .opblock.opblock-delete { border-color: #f93e3e; background: rgba(249, 62, 62, 0.05); }
    .swagger-ui .opblock.opblock-patch { border-color: #50e3c2; background: rgba(80, 227, 194, 0.05); }
  `;

  SwaggerModule.setup('api-docs', app, document, {
    customCss,
    customSiteTitle: 'Telegram Store API Documentation',
    customfavIcon: 'https://nestjs.com/img/logo-small.svg',
  });

  const port = configService.get<number>('PORT', 3000);
  await app.listen(port, '0.0.0.0');

  logger.log(`✨ Application is running on: http://localhost:${port}`);
  logger.log(`📖 API Documentation: http://localhost:${port}/api-docs`);
  logger.log(`👋 Environment: ${configService.get<string>('NODE_ENV', 'development')}`);
}

bootstrap();

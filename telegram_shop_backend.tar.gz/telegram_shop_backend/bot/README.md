# Telegram Shop Bot

Бот для Telegram-магазина на Node.js/TypeScript с использованием Grammy framework.

## Возможности

- 📚 Просмотр каталога товаров с пагинацией
- 🎨 Выбор вариантов товара (цвет/размер)
- 🛍 Оформление заказа (одноступенчатая покупка)
- 👤 Автозаполнение данных из Telegram профиля
- 🔔 Уведомления клиентам и админам
- 📄 Просмотр истории заказов
- ⌨️ Inline keyboards для удобной навигации

## Технологический стек

- **Grammy** - современный Telegram Bot framework
- **TypeScript** - типизированный JavaScript
- **Axios** - HTTP клиент для API
- **Winston** - логирование

## Установка

### Предварительные требования

- Node.js 18+
- Yarn
- Telegram Bot Token (получите от [@BotFather](https://t.me/botfather))

### Установка зависимостей

```bash
cd bot
yarn install
```

### Настройка

1. Скопируйте `.env.example` в `.env`:

```bash
cp .env.example .env
```

2. Заполните `.env` файл:

```env
# Telegram Bot Token от @BotFather
BOT_TOKEN=your_telegram_bot_token_here

# URL Backend API
API_BASE_URL=http://localhost:3000/api

# Telegram ID админов (через запятую)
ADMIN_TELEGRAM_IDS=123456789,987654321
```

### Запуск

#### Development

```bash
yarn dev
```

#### Production

```bash
# Сборка
yarn build

# Запуск
yarn start
```

## Структура проекта

```
bot/
├── src/
│   ├── config/           # Конфигурация
│   ├── conversations/    # Conversation flows
│   ├── handlers/         # Обработчики команд
│   ├── middleware/       # Middleware
│   ├── services/         # Сервисы (API, уведомления)
│   ├── types/            # TypeScript типы
│   ├── utils/            # Утилиты
│   └── index.ts          # Точка входа
├── .env.example        # Пример конфигурации
├── package.json
├── tsconfig.json
└── README.md
```

## Команды бота

- `/start` - Главное меню
- `/catalog` - Просмотр каталога
- `/orders` - Мои заказы
- `/profile` - Мой профиль
- `/cancel` - Отмена текущей операции

## Интеграция с Backend API

Бот взаимодействует с Backend API через HTTP:

- `GET /api/products` - Список товаров
- `GET /api/products/:id` - Детали товара
- `POST /api/orders` - Создание заказа
- `GET /api/orders` - Список заказов
- `POST /api/users/upsert` - Создание/обновление пользователя

## Docker

```bash
# Сборка образа
docker build -t telegram-shop-bot .

# Запуск
docker run -d --name bot --env-file .env telegram-shop-bot
```

## Логи

Логи сохраняются в:
- `logs/error.log` - ошибки
- `logs/combined.log` - все логи

## Разработка

### Добавление нового handler

1. Создайте файл в `src/handlers/`
2. Реализуйте логику handler
3. Зарегистрируйте в `src/index.ts`

### Добавление conversation

1. Создайте файл в `src/conversations/`
2. Реализуйте conversation flow
3. Зарегистрируйте в `src/index.ts` с `createConversation()`

## Поддержка

По вопросам обращайтесь к разработчикам.

## Лицензия

ISC

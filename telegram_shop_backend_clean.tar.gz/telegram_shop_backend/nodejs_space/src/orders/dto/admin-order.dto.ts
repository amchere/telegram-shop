import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional, IsString, IsIn, Min, Max } from 'class-validator';
import { Type } from 'class-transformer';

export class AdminOrderQueryDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  @IsIn(['pending', 'processing', 'shipped', 'delivered', 'cancelled'])
  status?: string;

  @ApiProperty({ required: false, default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number = 1;

  @ApiProperty({ required: false, default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(100)
  size?: number = 20;
}

export class AdminOrderListItemDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  user_id: string;

  @ApiProperty()
  status: string;

  @ApiProperty()
  total_amount: number;

  @ApiProperty()
  created_at: Date;
}

export class AdminOrderListResponseDto {
  @ApiProperty({ type: [AdminOrderListItemDto] })
  items: AdminOrderListItemDto[];

  @ApiProperty()
  total: number;

  @ApiProperty()
  page: number;

  @ApiProperty()
  size: number;
}

export class AdminOrderItemDetailDto {
  @ApiProperty()
  variant_id: number;

  @ApiProperty()
  sku: string;

  @ApiProperty()
  product_name: string;

  @ApiProperty()
  quantity: number;

  @ApiProperty()
  price_at_purchase: number;
}

export class AdminOrderDetailDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  user_id: string;

  @ApiProperty()
  status: string;

  @ApiProperty()
  total_amount: number;

  @ApiProperty()
  shipping_address: string;

  @ApiProperty()
  customer_contact: string;

  @ApiProperty()
  created_at: Date;

  @ApiProperty()
  updated_at: Date;

  @ApiProperty({ type: [AdminOrderItemDetailDto] })
  items: AdminOrderItemDetailDto[];
}

export class UpdateOrderStatusDto {
  @ApiProperty({ enum: ['pending', 'processing', 'shipped', 'delivered', 'cancelled'] })
  @IsString()
  @IsIn(['pending', 'processing', 'shipped', 'delivered', 'cancelled'])
  status: string;
}

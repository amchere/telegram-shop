import { Injectable, BadRequestException, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { OrderResponseDto } from './dto/order-response.dto';
import { AdminOrderQueryDto, AdminOrderListResponseDto, AdminOrderDetailDto, UpdateOrderStatusDto } from './dto/admin-order.dto';

@Injectable()
export class OrdersService {
  private readonly logger = new Logger(OrdersService.name);

  constructor(private prisma: PrismaService) {}

  async createOrder(dto: CreateOrderDto): Promise<OrderResponseDto> {
    this.logger.log(`Creating order for user ID: ${dto.user_id}`);

    // Verify all variants exist and have sufficient stock
    for (const item of dto.items) {
      const variant = await this.prisma.product_variants.findUnique({
        where: { id: item.variant_id },
        include: { product: true },
      });

      if (!variant) {
        throw new BadRequestException(`Product variant ${item.variant_id} not found`);
      }

      if (variant.stock_quantity < item.quantity) {
        throw new BadRequestException(
          `Product variant ${item.variant_id} (${variant.sku}) is out of stock. Available: ${variant.stock_quantity}`,
        );
      }
    }

    // Calculate total amount
    let totalAmount = 0;
    for (const item of dto.items) {
      const variant = await this.prisma.product_variants.findUnique({
        where: { id: item.variant_id },
      });
      totalAmount += Number(variant!.price) * item.quantity;
    }

    // Create or update user
    await this.prisma.users.upsert({
      where: { id: BigInt(dto.user_id) },
      update: {
        full_name: dto.user_details.full_name,
        phone_number: dto.user_details.phone_number,
      },
      create: {
        id: BigInt(dto.user_id),
        full_name: dto.user_details.full_name,
        phone_number: dto.user_details.phone_number,
      },
    });

    // Create order
    const order = await this.prisma.orders.create({
      data: {
        user_id: BigInt(dto.user_id),
        status: 'pending',
        total_amount: totalAmount,
        shipping_address: dto.shipping_address,
        customer_contact: `${dto.user_details.full_name}, ${dto.user_details.phone_number}`,
        items: {
          create: await Promise.all(
            dto.items.map(async (item) => {
              const variant = await this.prisma.product_variants.findUnique({
                where: { id: item.variant_id },
              });
              return {
                variant_id: item.variant_id,
                quantity: item.quantity,
                price_at_purchase: variant!.price,
              };
            }),
          ),
        },
      },
      include: {
        items: {
          include: {
            variant: {
              include: {
                product: true,
              },
            },
          },
        },
      },
    });

    // Decrement stock
    for (const item of dto.items) {
      await this.prisma.product_variants.update({
        where: { id: item.variant_id },
        data: {
          stock_quantity: {
            decrement: item.quantity,
          },
        },
      });
    }

    this.logger.log(`Order created with ID: ${order.id}`);

    return {
      id: order.id,
      status: order.status,
      total_amount: Number(order.total_amount),
      created_at: order.created_at,
      items: order.items.map((item) => ({
        product_name: item.variant.product.name,
        quantity: item.quantity,
        price: Number(item.price_at_purchase),
      })),
    };
  }

  async getAdminOrders(query: AdminOrderQueryDto): Promise<AdminOrderListResponseDto> {
    const { status, page = 1, size = 20 } = query;
    const skip = (page - 1) * size;

    const where: any = {};
    if (status) {
      where.status = status;
    }

    const [orders, total] = await Promise.all([
      this.prisma.orders.findMany({
        where,
        skip,
        take: size,
        orderBy: { created_at: 'desc' },
      }),
      this.prisma.orders.count({ where }),
    ]);

    const items = orders.map((order) => ({
      id: order.id,
      user_id: order.user_id.toString(),
      status: order.status,
      total_amount: Number(order.total_amount),
      created_at: order.created_at,
    }));

    return { items, total, page, size };
  }

  async getAdminOrderById(id: number): Promise<AdminOrderDetailDto> {
    const order = await this.prisma.orders.findUnique({
      where: { id },
      include: {
        items: {
          include: {
            variant: {
              include: {
                product: true,
              },
            },
          },
        },
      },
    });

    if (!order) {
      throw new NotFoundException(`Order with ID ${id} not found`);
    }

    return {
      id: order.id,
      user_id: order.user_id.toString(),
      status: order.status,
      total_amount: Number(order.total_amount),
      shipping_address: order.shipping_address,
      customer_contact: order.customer_contact,
      created_at: order.created_at,
      updated_at: order.updated_at,
      items: order.items.map((item) => ({
        variant_id: item.variant_id,
        sku: item.variant.sku,
        product_name: item.variant.product.name,
        quantity: item.quantity,
        price_at_purchase: Number(item.price_at_purchase),
      })),
    };
  }

  async updateOrderStatus(id: number, dto: UpdateOrderStatusDto): Promise<AdminOrderDetailDto> {
    this.logger.log(`Updating order ${id} status to: ${dto.status}`);

    const order = await this.prisma.orders.findUnique({ where: { id } });
    if (!order) {
      throw new NotFoundException(`Order with ID ${id} not found`);
    }

    await this.prisma.orders.update({
      where: { id },
      data: { status: dto.status },
    });

    this.logger.log(`Order ${id} status updated`);
    return this.getAdminOrderById(id);
  }
}

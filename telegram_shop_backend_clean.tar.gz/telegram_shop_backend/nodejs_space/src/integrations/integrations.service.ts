import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';
import { firstValueFrom } from 'rxjs';

export interface AnalyticsEvent {
  event_name: string;
  user_id: string;
  params?: Record<string, any>;
}

@Injectable()
export class IntegrationsService {
  private readonly logger = new Logger(IntegrationsService.name);
  private readonly gaEnabled: boolean;
  private readonly yandexEnabled: boolean;

  constructor(
    private httpService: HttpService,
    private configService: ConfigService,
  ) {
    this.gaEnabled = !!this.configService.get('GA_MEASUREMENT_ID');
    this.yandexEnabled = !!this.configService.get('YANDEX_METRIKA_ID');

    if (this.gaEnabled) {
      this.logger.log('✅ Google Analytics integration enabled');
    }
    if (this.yandexEnabled) {
      this.logger.log('✅ Yandex Metrika integration enabled');
    }
  }

  async sendEvent(event: AnalyticsEvent): Promise<void> {
    await Promise.all([
      this.sendToGoogleAnalytics(event),
      this.sendToYandexMetrika(event),
    ]);
  }

  private async sendToGoogleAnalytics(event: AnalyticsEvent): Promise<void> {
    if (!this.gaEnabled) return;

    try {
      const measurementId = this.configService.get<string>('GA_MEASUREMENT_ID');
      const apiSecret = this.configService.get<string>('GA_API_SECRET');

      const url = `https://www.google-analytics.com/mp/collect?measurement_id=${measurementId}&api_secret=${apiSecret}`;

      const payload = {
        client_id: event.user_id,
        events: [
          {
            name: event.event_name,
            params: event.params || {},
          },
        ],
      };

      await firstValueFrom(
        this.httpService.post(url, payload, {
          headers: { 'Content-Type': 'application/json' },
        }),
      );

      this.logger.debug(`GA event sent: ${event.event_name}`);
    } catch (error) {
      this.logger.error('Failed to send event to Google Analytics', error);
    }
  }

  private async sendToYandexMetrika(event: AnalyticsEvent): Promise<void> {
    if (!this.yandexEnabled) return;

    try {
      const metrikaId = this.configService.get<string>('YANDEX_METRIKA_ID');
      const url = `https://mc.yandex.ru/watch/${metrikaId}`;

      const params = {
        'page-url': event.params?.page_url || 'telegram://shop',
        'browser-info': `event:${event.event_name}`,
        rn: Math.random(),
      };

      await firstValueFrom(
        this.httpService.get(url, { params }),
      );

      this.logger.debug(`Yandex event sent: ${event.event_name}`);
    } catch (error) {
      this.logger.error('Failed to send event to Yandex Metrika', error);
    }
  }

  // Specific event methods
  async trackProductView(userId: string, productId: number, productName: string): Promise<void> {
    await this.sendEvent({
      event_name: 'view_item',
      user_id: userId,
      params: {
        item_id: productId,
        item_name: productName,
      },
    });
  }

  async trackAddToCart(userId: string, productId: number, productName: string, quantity: number): Promise<void> {
    await this.sendEvent({
      event_name: 'add_to_cart',
      user_id: userId,
      params: {
        item_id: productId,
        item_name: productName,
        quantity,
      },
    });
  }

  async trackPurchase(userId: string, orderId: number, totalAmount: number, items: any[]): Promise<void> {
    await this.sendEvent({
      event_name: 'purchase',
      user_id: userId,
      params: {
        transaction_id: orderId,
        value: totalAmount,
        currency: 'USD',
        items,
      },
    });
  }
}

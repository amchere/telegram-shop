import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  Logger,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class AuditLogInterceptor implements NestInterceptor {
  private readonly logger = new Logger(AuditLogInterceptor.name);

  constructor(private prisma: PrismaService) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const request = context.switchToHttp().getRequest();
    const { user, method, url, body } = request;

    // Only log admin actions (POST, PUT, PATCH, DELETE)
    if (!user || !['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
      return next.handle();
    }

    const action = method === 'DELETE' ? 'DELETE' : 
                   method === 'POST' ? 'CREATE' : 'UPDATE';
    
    // Extract entity type from URL (e.g., /admin/products/123 -> products)
    const urlMatch = url.match(/\/admin\/(\w+)/);
    const entityType = urlMatch ? urlMatch[1] : 'unknown';
    const entityIdMatch = url.match(/\/(\d+)$/);
    const entityId = entityIdMatch ? parseInt(entityIdMatch[1]) : null;

    return next.handle().pipe(
      tap(async () => {
        try {
          await this.prisma.audit_logs.create({
            data: {
              admin_user_id: user.id,
              action,
              entity_type: entityType,
              entity_id: entityId,
              changes: JSON.stringify(body),
            },
          });
        } catch (error) {
          this.logger.error('Failed to create audit log', error);
        }
      }),
    );
  }
}

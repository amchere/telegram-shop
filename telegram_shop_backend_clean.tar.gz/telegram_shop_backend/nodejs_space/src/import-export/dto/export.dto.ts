import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsDateString, IsUrl } from 'class-validator';

export class ExportQueryDto {
  @ApiProperty({ required: false, example: '2025-11-01' })
  @IsOptional()
  @IsDateString()
  start_date?: string;

  @ApiProperty({ required: false, example: '2025-11-30' })
  @IsOptional()
  @IsDateString()
  end_date?: string;
}

export class GoogleSheetsExportDto extends ExportQueryDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsUrl()
  spreadsheet_url?: string;
}

export class GoogleSheetsExportResponseDto {
  @ApiProperty()
  spreadsheet_url: string;

  @ApiProperty()
  message: string;
}

import { Controller, Post, Get, Body, UseGuards, UseInterceptors, UploadedFile, Res, Query, Logger, BadRequestException } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiConsumes, ApiBody } from '@nestjs/swagger';
import type { Response } from 'express';
import { ImportExportService } from './import-export.service';
import { GoogleSheetsImportDto, ImportResponseDto } from './dto/import.dto';
import { ExportQueryDto, GoogleSheetsExportDto, GoogleSheetsExportResponseDto } from './dto/export.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';

@ApiTags('Admin - Import/Export')
@Controller('admin')
@UseGuards(JwtAuthGuard, RolesGuard)
@ApiBearerAuth()
export class ImportExportController {
  private readonly logger = new Logger(ImportExportController.name);

  constructor(private readonly importExportService: ImportExportService) {}

  @Post('import/csv')
  @Roles('admin', 'manager')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiOperation({ summary: 'Import products from CSV' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @ApiResponse({ status: 202, type: ImportResponseDto })
  async importCSV(@UploadedFile() file: Express.Multer.File): Promise<ImportResponseDto> {
    if (!file) {
      throw new BadRequestException('File is required');
    }
    this.logger.log('Importing from CSV');
    return this.importExportService.importFromCSV(file);
  }

  @Post('import/xlsx')
  @Roles('admin', 'manager')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiOperation({ summary: 'Import products from XLSX' })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @ApiResponse({ status: 202, type: ImportResponseDto })
  async importXLSX(@UploadedFile() file: Express.Multer.File): Promise<ImportResponseDto> {
    if (!file) {
      throw new BadRequestException('File is required');
    }
    this.logger.log('Importing from XLSX');
    return this.importExportService.importFromXLSX(file);
  }

  @Post('import/google-sheets')
  @Roles('admin', 'manager')
  @ApiOperation({ summary: 'Import products from Google Sheets' })
  @ApiResponse({ status: 202, type: ImportResponseDto })
  async importGoogleSheets(@Body() dto: GoogleSheetsImportDto): Promise<ImportResponseDto> {
    this.logger.log('Importing from Google Sheets');
    return this.importExportService.importFromGoogleSheets(dto);
  }

  @Get('export/csv')
  @Roles('admin', 'manager')
  @ApiOperation({ summary: 'Export orders to CSV' })
  @ApiResponse({ status: 200, description: 'CSV file' })
  async exportCSV(@Query() query: ExportQueryDto, @Res() res: Response): Promise<void> {
    this.logger.log('Exporting to CSV');
    const buffer = await this.importExportService.exportToCSV(query);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=orders.csv');
    res.send(buffer);
  }

  @Get('export/xlsx')
  @Roles('admin', 'manager')
  @ApiOperation({ summary: 'Export orders to XLSX' })
  @ApiResponse({ status: 200, description: 'XLSX file' })
  async exportXLSX(@Query() query: ExportQueryDto, @Res() res: Response): Promise<void> {
    this.logger.log('Exporting to XLSX');
    const buffer = await this.importExportService.exportToXLSX(query);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=orders.xlsx');
    res.send(buffer);
  }

  @Post('export/google-sheets')
  @Roles('admin', 'manager')
  @ApiOperation({ summary: 'Export orders to Google Sheets' })
  @ApiResponse({ status: 200, type: GoogleSheetsExportResponseDto })
  async exportGoogleSheets(@Body() dto: GoogleSheetsExportDto): Promise<GoogleSheetsExportResponseDto> {
    this.logger.log('Exporting to Google Sheets');
    return this.importExportService.exportToGoogleSheets(dto);
  }
}

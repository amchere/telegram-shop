import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsString, IsOptional } from 'class-validator';

export class UserDto {
  @ApiProperty()
  id: string;

  @ApiProperty({ nullable: true })
  telegram_id?: string | null;

  @ApiProperty()
  full_name: string;

  @ApiProperty({ nullable: true })
  username: string | null;

  @ApiProperty({ nullable: true })
  phone_number: string | null;

  @ApiProperty()
  created_at: Date;
}

export class UpsertTelegramUserDto {
  @ApiProperty({ description: 'Telegram user ID' })
  @IsNumber()
  telegram_id: number;

  @ApiProperty({ required: false, description: 'Telegram username' })
  @IsOptional()
  @IsString()
  username?: string;

  @ApiProperty({ required: false, description: 'Full name of the user' })
  @IsOptional()
  @IsString()
  full_name?: string;

  @ApiProperty({ required: false, description: 'Phone number' })
  @IsOptional()
  @IsString()
  phone_number?: string;
}

export class UserDetailDto extends UserDto {
  @ApiProperty()
  orders_count: number;

  @ApiProperty()
  total_spent: number;
}

export class UserListResponseDto {
  @ApiProperty({ type: [UserDto] })
  items: UserDto[];

  @ApiProperty()
  total: number;

  @ApiProperty()
  page: number;

  @ApiProperty()
  size: number;
}

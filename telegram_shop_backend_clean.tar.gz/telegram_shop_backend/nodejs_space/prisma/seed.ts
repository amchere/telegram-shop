import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Create admin user
  const hashedPassword = await bcrypt.hash('admin123', 10);
  const admin = await prisma.admin_users.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      email: 'admin@telegram-shop.com',
      password_hash: hashedPassword,
      role: 'admin',
      is_active: true,
    },
  });
  console.log('✅ Admin user created:', admin.username);

  // Create categories
  const categories = await Promise.all([
    prisma.categories.upsert({
      where: { id: 1 },
      update: {},
      create: { id: 1, name: 'Clothing' },
    }),
    prisma.categories.upsert({
      where: { id: 2 },
      update: {},
      create: { id: 2, name: 'Electronics' },
    }),
    prisma.categories.upsert({
      where: { id: 3 },
      update: {},
      create: { id: 3, name: 'Accessories' },
    }),
  ]);
  console.log('✅ Categories created:', categories.length);

  // Create option types
  const colorType = await prisma.option_types.upsert({
    where: { name: 'Color' },
    update: {},
    create: { name: 'Color' },
  });

  const sizeType = await prisma.option_types.upsert({
    where: { name: 'Size' },
    update: {},
    create: { name: 'Size' },
  });
  console.log('✅ Option types created');

  // Create option values
  const colors = await Promise.all([
    prisma.option_values.upsert({
      where: { id: 1 },
      update: {},
      create: { option_type_id: colorType.id, value: 'Red' },
    }),
    prisma.option_values.upsert({
      where: { id: 2 },
      update: {},
      create: { option_type_id: colorType.id, value: 'Blue' },
    }),
    prisma.option_values.upsert({
      where: { id: 3 },
      update: {},
      create: { option_type_id: colorType.id, value: 'Black' },
    }),
  ]);

  const sizes = await Promise.all([
    prisma.option_values.upsert({
      where: { id: 4 },
      update: {},
      create: { option_type_id: sizeType.id, value: 'S' },
    }),
    prisma.option_values.upsert({
      where: { id: 5 },
      update: {},
      create: { option_type_id: sizeType.id, value: 'M' },
    }),
    prisma.option_values.upsert({
      where: { id: 6 },
      update: {},
      create: { option_type_id: sizeType.id, value: 'L' },
    }),
  ]);
  console.log('✅ Option values created');

  // Create sample products
  const tshirt = await prisma.products.upsert({
    where: { id: 1 },
    update: {},
    create: {
      id: 1,
      name: 'Classic T-Shirt',
      description: 'A comfortable 100% cotton t-shirt',
      category_id: 1,
      is_active: true,
    },
  });

  // Create variants for t-shirt
  const variants = [
    { sku: 'TS-RED-M', color: 'Red', size: 'M', price: 19.99, stock: 50 },
    { sku: 'TS-RED-L', color: 'Red', size: 'L', price: 19.99, stock: 40 },
    { sku: 'TS-BLUE-M', color: 'Blue', size: 'M', price: 21.99, stock: 30 },
    { sku: 'TS-BLUE-L', color: 'Blue', size: 'L', price: 21.99, stock: 25 },
  ];

  for (const v of variants) {
    const variant = await prisma.product_variants.upsert({
      where: { sku: v.sku },
      update: {},
      create: {
        product_id: tshirt.id,
        sku: v.sku,
        price: v.price,
        stock_quantity: v.stock,
        images: [],
      },
    });

    // Link variant to option values
    const colorValue = colors.find((c) => c.value === v.color);
    const sizeValue = sizes.find((s) => s.value === v.size);

    if (colorValue) {
      await prisma.variant_values.upsert({
        where: {
          variant_id_option_value_id: {
            variant_id: variant.id,
            option_value_id: colorValue.id,
          },
        },
        update: {},
        create: {
          variant_id: variant.id,
          option_value_id: colorValue.id,
        },
      });
    }

    if (sizeValue) {
      await prisma.variant_values.upsert({
        where: {
          variant_id_option_value_id: {
            variant_id: variant.id,
            option_value_id: sizeValue.id,
          },
        },
        update: {},
        create: {
          variant_id: variant.id,
          option_value_id: sizeValue.id,
        },
      });
    }
  }
  console.log('✅ Sample products and variants created');

  console.log('🎉 Seeding completed!');
  console.log('\n📝 Default admin credentials:');
  console.log('   Username: admin');
  console.log('   Password: admin123');
}

main()
  .catch((e) => {
    console.error('❌ Seeding failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

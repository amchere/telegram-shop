import { Bot, InlineKeyboard } from 'grammy';
import type { BotContext } from '../types';

/**
 * Register profile handlers
 */
export function registerProfileHandlers(bot: Bot<BotContext>) {
  // Profile command
  bot.command('profile', async (ctx) => {
    await showProfile(ctx);
  });

  bot.callbackQuery('profile', async (ctx) => {
    await ctx.answerCallbackQuery();
    await showProfile(ctx);
  });
}

/**
 * Show user profile
 */
async function showProfile(ctx: BotContext) {
  const user = ctx.session.userData;

  if (!user) {
    await ctx.reply('❌ Профиль не найден.');
    return;
  }

  let text = `👤 **Мой профиль**\n\n`;
  text += `Имя: ${user.firstName || 'Не указано'}\n`;
  if (user.lastName) text += `Фамилия: ${user.lastName}\n`;
  if (user.username) text += `Username: @${user.username}\n`;
  if (user.phone) text += `Телефон: ${user.phone}\n`;
  if (user.email) text += `Email: ${user.email}\n`;

  const keyboard = new InlineKeyboard()
    .text('📄 Мои заказы', 'orders:page:1')
    .row()
    .text('🏠 Главное меню', 'back:menu');

  if (ctx.callbackQuery) {
    await ctx.editMessageText(text, {
      parse_mode: 'Markdown',
      reply_markup: keyboard,
    });
  } else {
    await ctx.reply(text, {
      parse_mode: 'Markdown',
      reply_markup: keyboard,
    });
  }
}

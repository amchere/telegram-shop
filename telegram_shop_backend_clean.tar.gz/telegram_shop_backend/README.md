# Telegram Shop Backend

**Комплексное решение для интернет-магазина в Telegram**

## 🚀 Структура проекта

```
telegram_shop_backend/
├── nodejs_space/          # REST API на NestJS
│   ├── src/               # Исходный код API
│   ├── prisma/            # Схема и миграции БД
│   └── test/              # E2E тесты
├── bot/                   # Telegram бот на Grammy
│   ├── src/               # Исходный код бота
│   └── logs/              # Логи бота (генерируются автоматически)
├── docker-compose.yml     # Docker Compose конфигурация
└── Dockerfile             # Dockerfile для API
```

## 📦 Технологический стек

### Backend API
- **NestJS 11.0** - прогрессивный Node.js фреймворк
- **Prisma 6.0** - современный ORM для PostgreSQL
- **PostgreSQL 15** - реляционная база данных
- **JWT** - аутентификация и авторизация
- **Swagger/OpenAPI** - документация API

### Telegram Bot
- **Grammy 1.38.4** - современный фреймворк для Telegram ботов
- **TypeScript 5.9.3** - строгая типизация
- **Axios** - HTTP клиент для API
- **Winston** - логирование

## 🔧 Быстрый старт

### С помощью Docker Compose (рекомендуется)

```bash
# 1. Клонируйте проект
cd telegram_shop_backend

# 2. Создайте .env файл
cp nodejs_space/.env.example nodejs_space/.env
cp bot/.env.example bot/.env

# 3. Настройте переменные окружения
# Отредактируйте nodejs_space/.env и bot/.env

# 4. Запустите все сервисы
docker-compose up -d

# 5. Выполните миграции БД
docker-compose exec api npx prisma migrate deploy
docker-compose exec api npx prisma db seed
```

### Локальная разработка

```bash
# Backend API
cd nodejs_space
yarn install
yarn prisma generate
yarn prisma migrate dev
yarn prisma db seed
yarn start:dev  # Запуск на http://localhost:3000

# Telegram Bot (в отдельном терминале)
cd bot
yarn install
yarn dev
```

## 🌐 Доступ к сервисам

### Production
- **API**: https://smokyyard.abacusai.app
- **API Docs**: https://smokyyard.abacusai.app/api-docs
- **Telegram Bot**: [@SmokyYardBot](https://t.me/SmokyYardBot)

### Local Development
- **API**: http://localhost:3000
- **API Docs**: http://localhost:3000/api-docs
- **Database**: localhost:5432

## 🔑 Учетные данные по умолчанию

**⚠️ Обязательно измените в production!**

```
Администратор:
Username: admin
Password: admin123
```

## 📚 Основные возможности

### REST API
- ✅ Управление продуктами и категориями
- ✅ Варианты товаров (размер, цвет и т.д.)
- ✅ Обработка заказов
- ✅ JWT аутентификация
- ✅ Роли пользователей (admin, manager)
- ✅ Импорт/экспорт CSV
- ✅ Webhook интеграции
- ✅ Swagger документация

### Telegram Bot
- ✅ Просмотр каталога товаров
- ✅ Выбор вариантов товара
- ✅ Оформление заказов (8-шаговый процесс)
- ✅ История заказов
- ✅ Профиль пользователя
- ✅ Автоматические уведомления
- ✅ Обработка ошибок

## 🗄️ База данных

**11 таблиц:**
- `users` - пользователи Telegram
- `admin_users` - администраторы системы
- `categories` - категории товаров
- `products` - товары
- `product_variants` - варианты товаров
- `option_types` - типы опций (размер, цвет)
- `option_values` - значения опций (M, L, XL)
- `variant_values` - связь вариантов с опциями
- `orders` - заказы
- `order_items` - товары в заказах
- `audit_logs` - логи аудита

## 📖 Документация

Полная документация находится в `/home/ubuntu/telegram_shop_docs/`:

- **README.md** - обзор проекта
- **ARCHITECTURE.md** - архитектура системы
- **SETUP.md** - установка и настройка
- **API_DOCUMENTATION.md** - документация API
- **BOT_LOGIC.md** - логика работы бота
- **DATABASE.md** - схема базы данных
- **ENVIRONMENT.md** - переменные окружения
- **DOCKER.md** - работа с Docker
- **DEVELOPMENT.md** - руководство разработчика
- **TROUBLESHOOTING.md** - решение проблем

## 🔧 Полезные команды

```bash
# Docker Compose
docker-compose up -d              # Запустить все сервисы
docker-compose down               # Остановить все сервисы
docker-compose logs -f api        # Логи API
docker-compose logs -f bot        # Логи бота
docker-compose restart api        # Перезапустить API

# Prisma (внутри контейнера или локально)
npx prisma studio                 # Открыть Prisma Studio
npx prisma migrate dev            # Создать миграцию
npx prisma db seed                # Заполнить тестовыми данными

# API (nodejs_space/)
yarn start:dev                    # Запуск в dev режиме
yarn build                        # Сборка для production
yarn test:e2e                     # E2E тесты

# Bot (bot/)
yarn dev                          # Запуск в dev режиме
yarn build                        # Компиляция TypeScript
```

## 🐛 Решение проблем

### База данных не запускается
```bash
docker-compose down -v
docker-compose up -d postgres
```

### Бот не отвечает
```bash
# Проверьте логи
docker-compose logs -f bot

# Проверьте подключение к API
curl http://localhost:3000/api/health
```

### API возвращает ошибки
```bash
# Проверьте логи
docker-compose logs -f api

# Проверьте миграции
docker-compose exec api npx prisma migrate status
```

## 📝 Лицензия

Проект разработан для коммерческого использования.

## 📧 Контакты

- **Telegram Bot**: [@SmokyYardBot](https://t.me/SmokyYardBot)
- **API Documentation**: https://smokyyard.abacusai.app/api-docs

---

**Разработано с ❤️ для российского рынка электронной коммерции**